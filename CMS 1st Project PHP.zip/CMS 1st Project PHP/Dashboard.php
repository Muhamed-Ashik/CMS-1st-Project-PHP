<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php"); ?>
<?php
  $_SESSION["TrackingURL"] = $_SERVER["PHP_SELF"];
  Confirm_Login();
 ?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Style.css">
    <title>Dashboard</title>
  </head>
  <body>

    <!-- START OF THE NAVIGATION BAR -->

    <?php require_once("Includes/AdministratorNavigation.php"); ?>

    <!-- END OF THE NAVIGATION BAR -->

    <!-- START OF THE HEADER -->

    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1><i class="fas fa-cog" style="color: #27aae1;"></i> Dashboard</h1>
          </div><!--END OF THE COL-MD-12 -->

          <div class="col-md-3">
            <a href="AddNewPosts.php" class="btn btn-primary btn-block mb-2">
              <i class="fas fa-edit"></i> Add New Posts
            </a>
          </div>

          <div class="col-md-3">
            <a href="Categories.php" class="btn btn-info btn-block mb-2">
              <i class="fas fa-folder-plus"></i> Add Category
            </a>
          </div>

          <div class="col-md-3">
            <a href="AddNewAdmin.php" class="btn btn-warning btn-block mb-2">
              <i class="fas fa-user-plus"></i> Add New Admin
            </a>
          </div>

          <div class="col-md-3">
            <a href="Comments.php" class="btn btn-success btn-block mb-2">
              <i class="fas fa-check"></i> Approve Comments
            </a>
          </div>

        </div><!--END OF THE ROW-->
      </div><!--END OF THE CONTAINER-->
    </header>

    <!-- END OF THE HEADER -->

    <!-- START OF THE MAIN AREA -->
    <!-- LEFT SIDE AREA START -->
    <section class="container mt-4 mb-4 py-3" style="min-height: 594px;">
      <?php

      echo ErrorMessage();
      echo SuccessMessage();

      ?>
      <div class="row">
        <div class="col-lg-2 mt-2">

          <div class="card bg-dark text-white text-center mb-3">
            <div class="card-body">
              <h1 class="lead">Posts</h1>
              <h4 class="display-5">
                <i class="fab fa-readme"></i>
                <?php
                  echo TotalPosts();
                 ?>
              </h4>
            </div><!--END OF THE CARD-BODY-->
          </div><!--END OF THE CARD-->

          <div class="card bg-dark text-white text-center mb-3">
            <div class="card-body">
              <h1 class="lead">Categories</h1>
              <h4 class="display-5"><i class="fas fa-folder"></i>
              <?php
                echo TotalCategories();
               ?>
              </h4>
            </div>
          </div>

          <div class="card text-white bg-dark text-center mb-3">
            <div class="card-body">
              <h1 class="lead">Admin</h1>
              <h4 class="display-5">
                <i class="fas fa-users"></i>
                <?php
                  echo TotalAdmins();
                 ?>
              </h4>
            </div>
          </div>

          <div class="card bg-dark text-center text-white mb-3">
            <div class="card-body">
              <h1 class="lead">Comments</h1>
              <h4 class="display-5">
                <i class="fab fa-readme"></i>
                <?php
                  echo  TotalComments();
                 ?>
              </h4>
            </div>
          </div>

        </div><!--END OF THE COL-LG-2 -->

        <!-- END OF THE LEFT SIDE AREA -->

        <!-- START OF THE RIGHT SIDE AREA -->

        <div class="col-lg-10">
          <h1>Posts</h1>
          <table class="table">
            <thead>
              <tr>
                <th>No</th>
                <th>Title</th>
                <th>Date & Time</th>
                <th>Author</th>
                <th>Comments</th>
                <th>Details</th>
              </tr>
            </thead>

            <?php
              global $databaseConnection;
              $loopCount = 0;
              $sqlFetch = "SELECT * FROM posts ORDER BY id desc";
              $sqlFetchQuery = $databaseConnection->query($sqlFetch);
              while ($dataRows = $sqlFetchQuery->fetch()) {
                $postID = $dataRows["id"];
                $postTitle = $dataRows["title"];
                $postAddedDateTime = $dataRows["datetime"];
                $postAuthor = $dataRows["author"];
                $loopCount++;
             ?>

            <tbody>
              <tr>
                <td><?php echo $loopCount; ?></td>
                <td><?php echo $postTitle; ?></td>
                <td><?php echo $postAddedDateTime; ?></td>
                <td><?php echo $postAuthor; ?></td>
                <td>
                  <span class="badge badge-success">
                    <?php
                      echo ApprovedCommentsCount($postID);
                     ?>
                  </span>
                  <span class="badge badge-danger">
                    <?php
                      echo DisApprovedCommentsCount($postID)
                     ?>
                  </span>
                </td>
                <td><a href="FullPost.php?id=<?php echo $postID; ?>" target="_blank"><span class="btn btn-primary btn-sm">Live Preview</span></a></td>
              </tr>
            </tbody>

            <?php } // END OF THE WHILE LOOP ?>

          </table>
        </div> <!--END OF THE COL-LG-10 DIV-->

        <!-- END OF THE RIGHT SIDE AREA -->

      </div><!--END OF THE ROW-->
    </section>

    <!-- END OF THE MAIN AREA -->

    <!-- START OF THE FOOTER -->

    <?php require_once("Includes/Footer.php"); ?>

    <!-- END OF THE FOOTER -->


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <script type="text/javascript">
      $('#year').text(new Date().getFullYear());
    </script>

  </body>
  </html>
