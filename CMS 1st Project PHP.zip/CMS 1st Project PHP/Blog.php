<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Blog Page</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Style.css">

<style media="screen">
  .categories {
    font-family: Bitter, Georgia, "Times New Roman", Times, serif;
    font-weight: bold;
    color: #005E90;
  }

  .categories:hover{
    color: #0090DB;
  }

</style>

  </head>
  <body>

    <!-- START OF THE NAVIGATION BAR -->

      <div style="background-color: #27aae1; height: 10px;"></div>
      <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
      <div class="container">
        <a href="#" class="navbar-brand">ANS.COM</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapseNavbarCMS">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapseNavbarCMS">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="#" class="nav-link">Home</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">About Us</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">Blog</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">Contact Us</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">Features</a>
          </li>
        </ul>

        <ul class="navbar-nav">
          <form class="form-inline d-none d-sm-block" action="Blog.php">
            <div class="form-group">
              <input type="text" name="Search" placeholder="Search Here" class="form-control mr-2"/>
              <button class="btn btn-primary"  name="SearchButton">Go</button>
            </div>
          </form>
        </ul>

        </div><!-- END OF THE NAVBAR COLLAPSE DIV-->
      </div> <!--END OF THE CONTAINER DIV-->
    </nav>
    <div style="background-color: #27aae1; height: 10px;"></div>

    <!-- END OF THE NAVIGATION BAR -->

    <!-- START OF THE HEADER -->

    <section class="container">
      <div class="row mt-4">
        <div class="col-sm-8">
          <h1>The Complete Responsive CMS Blog</h1>
          <h1 class="lead">The Complete by Blog Using PHP by Mohamed Ashik</h1>
          <?php
          echo ErrorMessage();
          echo SuccessMessage();

           ?>
          <?php
          global $databaseConnection;

          if(isset($_GET["SearchButton"])) {
            // fetch the search result
            $search = $_GET["Search"];
            $sqlSearchFetch = "SELECT * FROM posts WHERE
              datetime LIKE :search OR
              title LIKE :search OR
              category LIKE :search OR
              postdescription LIKE :search";
            $sqlFetchQuery = $databaseConnection->prepare($sqlSearchFetch);
            $sqlFetchQuery->bindValue(':search', '%' . $search . '%');
            $sqlFetchQuery->execute();

          } elseif(isset($_GET["page"])) {
            // Pagination SQL Query (Limiting the post display)
            global $databaseConnection;
            $page = $_GET["page"];

            if($page == 0 || $page < 1 || $_SERVER["PHP_SELF"] != $page) {
              $postStartFrom = 0;
            } else {
            $postStartFrom = ($page*5)-5;
          }

          $sqlFetch = "SELECT * FROM posts ORDER BY id desc LIMIT $postStartFrom,5";
          $sqlFetchQuery = $databaseConnection->query($sqlFetch);

        } elseif(isset($_GET["category"])) {
          // QUERY TO FETCH THE CATEGORY FROM THE POSTS
          $categoryTitleFromURL = $_GET["category"];
          $sqlFetchCategory = "SELECT * FROM posts WHERE category=:categorY ORDER BY id desc";
          $sqlFetchQuery = $databaseConnection->prepare($sqlFetchCategory);
          $sqlFetchQuery->bindValue(':categorY', $categoryTitleFromURL);
          $sqlFetchQuery->execute();
        }

        else {
            // Default SQL Query
            $sqlFetch = "SELECT * FROM posts ORDER BY id desc LIMIT 0,3";
            $sqlFetchQuery = $databaseConnection->query($sqlFetch);

          }

          while($dataRows = $sqlFetchQuery->fetch()) {
            $id = $dataRows["id"];
            $dateTime = $dataRows["datetime"];
            $title = $dataRows["title"];
            $category = $dataRows["category"];
            $author = $dataRows["author"];
            $image = $dataRows["image"];
            $postDescription = $dataRows["postdescription"];

           ?>

           <div class="card mb-3">
             <img src="Uploads/<?php echo $image; ?>" class="img-fluid" style="max-height: 600px; ">;
             <div class="card-body">
               <h4 class="card-title"><?php echo htmlentities($title); ?></h4>
               <small class="text-muted">Category: <span class="text-dark"><?php echo $category; ?></span> & Written by <a href="Profile.php?username=<?php echo htmlentities($author); ?>" target="_blank" class="text-primary"><?php echo htmlentities($author); ?></a> On <span class="text-dark"><?php echo htmlentities($dateTime); ?></span></small>
               <span style="float:right;" class="badge badge-dark text-light">Comments: <?php echo ApprovedCommentsCount($id); ?></span>
               <hr>
               <p class="card-text">
                 <?php if(strlen($postDescription>150)) {
                   $postDescription = substr($postDescription,0,150).'...';
                 } ?>
                 <?php echo htmlentities($postDescription); ?></p>
               <a href="FullPost.php?id=<?php echo $id; ?>" style="float: right;"><span class="btn btn-info">Read More >></span></a>
             </div><!--END OF THE CARD BODY-->
           </div><!--END OF THE CARD-->

         <?php } ?>

         <!-- START OF THE PAGINATION -->
         <nav>
           <ul class="pagination pagination-lg">
             <?php
             if(isset($page)) {
               if($page > 1) {
             ?>

             <li class="page-item">
               <a href="Blog.php?page=<?php echo $page-1; ?>" class="page-link text-dark">&laquo;</a>
             </li>

             <?php
                } // END OF THE IF CONDITION
              } // END OF THE IF CONDITION
            ?>

             <?php
              global $databaseConnection;
              $sqlFetchPostCount = "SELECT COUNT(*) FROM posts"; // count of all posts
              $sqlFetchPostCountQuery = $databaseConnection->query($sqlFetchPostCount); // query the sql command
              $postCount = $sqlFetchPostCountQuery->fetch(); // fetch all the count
              $totalPostCount = array_shift($postCount); // array to string conversion
              // echo $totalPostCount. "<br>"; // print the total post count
              $postPagination = $totalPostCount / 5; // divide the total post count by the post count per page
              $postPagination = ceil($postPagination); // 2 pagination once divided by the per page post count
              //echo $postPagination;
              for($loop = 1; $loop <= $postPagination; $loop++) { // loop to iterate until the post count
                if(isset($page)) {
                  if($page == $loop) {
                    ?>
                    <li class="page-item active">
                      <a href="Blog.php?page=<?php echo $loop; ?>" class="page-link text-dark"><?php echo $loop; ?></a>
                    </li>
                    <?php
                  } else {
                      ?>
                      <li class="page-item">
                        <a href="Blog.php?page=<?php echo $loop; ?>" class="page-link text-dark"><?php echo $loop; ?></a>
                      </li>
                      <?php
                  }
              ?>
             <?php
              } // END OF THE IF
              } // END OF THE FOR LOOP
              ?>

              <!-- START OF THE FORWARD BUTTON-->
              <?php
              if(isset($page) && !empty($page)) {
                if($page+1 <= $postPagination) {
               ?>

              <li class="page-item">
                <a href="Blog.php?page=<?php echo $page+1; ?>" class="page-link text-dark">&raquo;</a>
              </li>

              <?php
                } // END OF THE IF
              } // END OF THE IF
              ?>
            <!-- END OF THE FORWARD BUTTON -->

           </ul>
         </nav>

         <!-- END OF THE PAGINATION -->

        </div><!--END OF THE col-sm-8 div-->

        <!-- START OF THE RIGHT SIDE AREA -->
        <div class="col-sm-4">
            <div class="card mt-3">
              <div class="card-body">
                <img src="Images/CodingForKids.jfif" class="img-fluid d-block mb-4" style="width: 100%;">
                <div class="">
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </div>
              </div><!--END OF THE CARD-BODY-->
            </div><!--END OF THE CARD-->
              <br>
            <div class="card mb-4">
              <div class="card-header bg-dark text-light">
                <h2 class="lead">Sign Up !</h2>
              </div>
              <div class="card-body">
                <button type="button" class="btn btn-success btn-block text-center mb-3" name="button">Join The Forum</button>
                <button type="button" class="btn btn-danger btn-block text-center mb-3" name="button">Login</button>
                <div class="input-group">
                  <input type="email" placeholder="Enter the email" class="form-control"/>
                  <div class="input-group-append">
                    <button type="button" name="button" class="btn btn-primary btn-block btn-sm text-center">Subscribe Now</button>
                  </div><!--END OF THE INPUT-GROUP-APPEND-->
                </div><!--END OF THE INPUT-GROUP-->
              </div><!--END OF THE CARD BODY-->
            </div><!--END OF THE CARD-->

            <div class="card mb-4">
              <div class="card-header bg-dark text-light">
                <h2 class="lead">Categories</h2>
              </div>
              <div class="card-body">
                <?php
                global $databaseConnection;
                $sqlFetchCategory = "SELECT * FROM category ORDER BY id desc";
                $sqlFetchCategoryQuery = $databaseConnection->query($sqlFetchCategory);
                while($dataRows = $sqlFetchCategoryQuery->fetch()) {
                  $categoryID = $dataRows["id"];
                  $categoryTitle = $dataRows["title"];
                 ?>
                 <a href="Blog.php?category=<?php echo $categoryTitle; ?>"><span class="categories d-block"><?php echo $categoryTitle; ?></span></a>
                 <?php   }// END OF THE WHILE LOOP ?>
              </div><!--END OF THE CARD-BODY-->
            </div><!--END OF THE CARD-->

            <div class="card">
              <div class="card-header bg-dark text-light">
                <h2 class="lead">Recent Posts</h2>
              </div><!--END OF THE CARD-HEADER-->
              <div class="card-body">
                <?php
                  global $databaseConnection;
                  $sqlFetch = "SELECT * FROM posts ORDER BY id desc LIMIT 0,5";
                  $sqlFetchQuery = $databaseConnection->query($sqlFetch);
                  while($dataRows = $sqlFetchQuery->fetch()) {
                    $postID = $dataRows["id"];
                    $postTitle = $dataRows["title"];
                    $postAddedDateTime = $dataRows["datetime"];
                    $postImage = $dataRows["image"];
                 ?>
                <div class="media">
                  <img src="Uploads/<?php echo $postImage; ?>" class="img-fluid d-block align-self-start mr-2" width="120" height="90">
                  <div class="media-body">
                    <a href="FullPost.php?id=<?php echo $postID; ?>" target="_blank" class="text-dark"><h6><?php echo $postTitle; ?></h6></a>
                    <p class="small"><?php echo $postAddedDateTime; ?></p>
                  </div><!--END OF THE MEDIA-BODY-->
                </div><!--END OF THE MEDIA -->

                <hr>

                <?php } // END OF THE WHILE LOOP ?>

              </div><!--END OF THE CARD-BODY-->
            </div><!--END OF THE CARD-->

        </div><!--END OF THE COL-SM-4 DIV-->
        <!-- END OF THE RIGHT SIDE AREA -->

      </div><!--END OF THE ROW-->
    </section>

    <!-- END OF THE HEADER -->

    <br>

    <!-- START OF THE FOOTER -->
      <?php require_once("Includes/Footer.php"); ?>
    <!-- END OF THE FOOTER -->


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <script type="text/javascript">
      $('#year').text(new Date().getFullYear());
    </script>

  </body>
</html>
