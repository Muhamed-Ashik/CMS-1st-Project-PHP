<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php
  $_SESSION["TrackingURL"] = $_SERVER["PHP_SELF"];
  Confirm_Login();
 ?>
 <?php
 // fetcing the admin username
 $adminUserID = $_SESSION["userId"];

 global $databaseConnection;
 $sqlFetchAdmin = "SELECT * FROM admins WHERE id='$adminUserID'";
 $sqlFetchAdminQuery = $databaseConnection->query($sqlFetchAdmin);
 while($dataRows = $sqlFetchAdminQuery->fetch()) {
   $logedAdminUserName = $dataRows["username"];
   $logedAdminName = $dataRows["adminname"];
   $logedAdminHeadline = $dataRows["adminheadline"];
   $logedAdminBio = $dataRows["adminbio"];
   $logedAdminImage = $dataRows["adminimage"];
 } // END OF THE WHILE LOOP

 // FETCHING THE EXISTING ADMIN DATA

 if(isset($_POST["Submit"])) {

   $adminName = $_POST["Name"];
   $adminHeadline = $_POST["Headline"];
   $adminBio = $_POST["Bio"];
   $image = $_FILES["Image"]["name"];
   $target = "Images/".basename($_FILES["Image"]["name"]);

   if(strlen($adminHeadline)>30) {
     $_SESSION["ErrorMessage"] = "Headline should be less than 30 characters";
     Redirect_to("MyProfile.php");
   } elseif(strlen($adminBio)>500) {
     $_SESSION["ErrorMessage"] = "Bio should be less than 500 characters";
     Redirect_to("MyProfile.php");
   } else {
     // update the admin table data when everything is fine
     if(!empty($_FILES["Image"]["name"])) {
       $sqlUpdate = "UPDATE admins
                     SET adminname='$adminName',
                     adminheadline='$adminHeadline',
                     adminbio='$adminBio',
                     adminimage='$image'
                     WHERE id='$adminUserID'";
     } else {
       $sqlUpdate = "UPDATE admins
       SET adminname='$adminName',
       adminheadline='$adminHeadline',
       adminbio='$adminBio',
       adminimage='Avatar.jpg'
       WHERE id='$adminUserID'";
     }

     $sqlUpdateQuery = $databaseConnection->query($sqlUpdate);
     move_uploaded_file($_FILES["Image"]["tmp_name"], $target);

     if($sqlUpdateQuery) {
       $_SESSION["SuccessMessage"] = "Record Updated Successfully";
       Redirect_to("MyProfile.php");
     } else {
       $_SESSION["ErrorMessage"] = "Someting Went Wrong on Updating Record | Try Again !";
       Redirect_to("MyProfile.php");
     }

   } // END OF THE ELSE BLCOK

 }

  ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Style.css">
    <title>My Profile</title>
  </head>
  <body>

    <!-- START OF THE NAVIGATION BAR -->

    <?php require_once("Includes/AdministratorNavigation.php"); ?>

    <!-- END OF THE NAVIGATION BAR -->

    <!-- START OF THE HEADER -->

    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
              <h1><i class="fas fa-user text-success" style="color: #27aae1;"></i> @<?php echo $logedAdminUserName; ?></h1>
          </div>
        </div>
      </div>
    </header>

    <!-- END OF THE HEADER -->

    <!-- START OF THE MAIN AREA -->

    <!-- START OF THE MAIN AREA -->

    <section class="container py-3 mb-5 mt-4" style="min-height: 620px;">
      <div class="row">

        <div class="col-md-3">
          <div class="card">
            <div class="card-header bg-dark text-light">
              <?php if(!empty($logedAdminName)) {
                  ?>
                    <h3><?php echo $logedAdminName; ?></h3>
                  <?php
              } else {
                  ?>
                  <h3 class="text-danger">No Name</h3>
                  <?php
              }
              ?>

            </div><!--END OF THE CARD-HEADER-->
            <div class="card-body">
              <img src="Images/<?php echo $logedAdminImage; ?>" class="img-fluid d-block mb-3" alt="My Profile">
              <small><?php echo $logedAdminHeadline; ?></small>
              <hr>
              <div class="">
                <?php echo $logedAdminBio; ?>
              </div>
            </div><!--END OF THE CARD BODY-->
          </div><!--END OF THE CARD-->
        </div><!--END OF THE COL-MD-3 DIV-->

        <div class="col-md-9" style="min-height: 300px;">
          <?php
          echo ErrorMessage();
          echo SuccessMessage();

           ?>
          <form action="MyProfile.php" method="post" enctype="multipart/form-data">
            <div class="card bg-secondary text-light mb-3">
              <div class="card-header">
                <h3>Edit Profile</h3>
              </div>
              <div class="card-body bg-dark">

                <div class="form-group">
                  <input type="text" name="Name" id="name" value="" class="form-control" placeholder="Enter the name"/>
                </div><!--END OF THE FORM-GROUP -->

                <div class="form-group">
                  <input type="text" name="Headline" id="headline" class="form-control" placeholder="Headline"/>
                  <small class="text-muted">Add a Proffessional Headline Like, 'Engineer' at XYZ or 'Architect' at XYZ</small>
                  <span class="text-danger">Not more than 30 characters</span>
                </div>

                <div class="form-group">
                  <textarea name="Bio" id="bio" rows="8" cols="80" placeholder="Bio" class="form-control" ></textarea>
                </div>

                <div class="form-group">
                  <div class="custom-file">
                    <input type="file" name="Image" id="image" class="form-control" class="custom-file-input"/>
                    <label for="image" class="custom-file-label">Select Image</label>
                  </div>
                </div>

                <div class="row">
                  <div class="col-lg-6 mb-2">
                    <a href="Dashboard.php" class="btn btn-warning btn-block"><i class="fas fa-arrow-left"></i> Back To Dashboard</a>
                  </div>
                  <div class="col-lg-6 mb-2">
                    <button type="submit" name="Submit" class="btn btn-success btn-block"><i class="fas fa-check"></i> Publish</button>
                  </div>
                </div>

              </div><!--END OF THE CARD-BODY-->
            </div><!--END OF THE CARD-->
          </form>

        </div>
      </section>


    <!-- END OF THE MAIN AREA -->


        <!-- START OF THE FOOTER -->

      <?php require_once("Includes/Footer.php"); ?>

        <!-- END OF THE FOOTER -->


        <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


        <script type="text/javascript">
          $('#year').text(new Date().getFullYear());
        </script>

      </body>
    </html>
