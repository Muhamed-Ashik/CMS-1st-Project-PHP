<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php Confirm_Login(); ?>

<?php

  if(isset($_GET["id"])) {
    $searchQueryParameter = $_GET["id"];
    global $databaseConnection;
    $adminUsername = $_SESSION["userName"];
    $sqlUpdate = "UPDATE comments SET status='ON', approvedby='$adminUsername' WHERE id='$searchQueryParameter'";
    $sqlExecute = $databaseConnection->query($sqlUpdate);

    if($sqlExecute) {
      $_SESSION["SuccessMessage"] = "Comment Approved Successfully";
      Redirect_to("Comments.php");
    } else {
      $_SESSION["ErrorMessage"] = "Someting Went Wrong on Approve Comments | Try Again";
      Redirect_to("Comments.php");
    }

  }
 ?>
