<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php Confirm_Login(); ?>

<?php

  if(isset($_GET["id"])) {
    $searchQueryParameter = $_GET["id"];
    global $databaseConnection;

    $sqlDelete = "DELETE FROM category WHERE id='$searchQueryParameter'";
    $sqlDeleteQuery = $databaseConnection->query($sqlDelete);

    if($sqlDeleteQuery) {
      $_SESSION["SuccessMessage"] = "Category Deleted Succesfully";
      Redirect_to("Categories.php");
    } else {
      $_SESSION["ErrorMessage"] = "Someting Went Wrong on Deleting Category";
      Redirect_to("Categories.php");
    }

  }

 ?>
