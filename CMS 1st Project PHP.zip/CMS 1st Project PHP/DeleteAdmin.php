<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php Confirm_Login(); ?>

<?php

  if(isset($_GET["id"])) {
    $searchQueryParameter = $_GET["id"];
    global $databaseConnection;
    $sqlDelete = "DELETE FROM admins WHERE id='$searchQueryParameter'";
    $sqlDeleteQuery = $databaseConnection->query($sqlDelete);

    if($sqlDeleteQuery) {
        $_SESSION["SuccessMessage"] = "Admin Deleted Successfully";
        Redirect_to("AddNewAdmin.php");
    } else {
      $_SESSION["ErrorMessage"] = "Someting Went Wrong on Deleting Admin";
      Redirect_to("AddNewAdmin.php");
    }

  }
 ?>
