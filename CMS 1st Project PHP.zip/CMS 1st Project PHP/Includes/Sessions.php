<?php

  session_start();

  function ErrorMessage() {
    if(isset($_SESSION["ErrorMessage"])) {
      $outPut = "<div class='alert alert-danger'>";
      $outPut .= htmlentities($_SESSION["ErrorMessage"]);
      $outPut .= "</div>";
      $_SESSION["ErrorMessage"] = null;
      return $outPut;
    }
  }

  function SuccessMessage() {
    if(isset($_SESSION["SuccessMessage"])) {
      $outPut = "<div class='alert alert-success'>";
      $outPut .= htmlentities($_SESSION["SuccessMessage"]);
      $outPut .= "</div>";
      $_SESSION["SuccessMessage"] = null;
      return $outPut;
    }
  }

 ?>
