<?php
  function Redirect_to($newLocation) {
    header("Location: ".$newLocation);
    exit;
  }

  function CheckUserNameExistsOrNot($username) {
    global $databaseConnection;
    $sqlFetchUsername = "SELECT username from admins WHERE username=:usernamE";
    $sqlFetchUsernamePrepare = $databaseConnection->prepare($sqlFetchUsername);
    $sqlFetchUsernamePrepare->bindValue(':usernamE', $username);
    $sqlFetchUsernamePrepare->execute();
    $result = $sqlFetchUsernamePrepare->rowcount(); // count the number of rows which are holding the username
    if($result == 1) {
      return true;
    } else {
      return false;
    }

  } // END OF THE checkUserNameExistsOrNot FUNCITON

  function Login_Attempt($username, $password) {

    global $databaseConnection;
    $sqlFetch = "SELECT * FROM admins WHERE username=:usernamE AND password=:passworD LIMIT 1";
    $sqlFetchPrepare = $databaseConnection->prepare($sqlFetch);
    $sqlFetchPrepare->bindValue(':usernamE', $username);
    $sqlFetchPrepare->bindValue(':passworD', $password);
    $sqlFetchPrepare->execute();
    $sqlFetchResult = $sqlFetchPrepare->rowcount();

    if($sqlFetchResult == 1) {
        return $accountFound = $sqlFetchPrepare->fetch();
    } else {
      return null;
    }

  } // END OF THE LOGIN ATTEMPT FUNCTION

  function Confirm_Login() {

    if(isset($_SESSION["userId"])) {
      return true;
    } else {
      $_SESSION["ErrorMessage"] = "Login Required !";
      Redirect_to("Login.php");
    }

  } // END OF THE CONFIRM_LOGIN FUNCTION

  function TotalPosts() {
    global $databaseConnection;
    $sqlFetch = "SELECT COUNT(*) FROM posts";
    $sqlFetchQuery = $databaseConnection->query($sqlFetch);
    $totalRows = $sqlFetchQuery->fetch();
    $totalRowsStringConverstion = array_shift($totalRows);
    return $totalRowsStringConverstion;
  }

  function TotalCategories() {
    global $databaseConnection;
    $sqlFetch = "SELECT COUNT(*) FROM category";
    $sqlFetchQuery = $databaseConnection->query($sqlFetch);
    $totalRows = $sqlFetchQuery->fetch();
    $totalRowsStringConverstion = array_shift($totalRows);
    return $totalRowsStringConverstion;
  }

  function TotalAdmins() {
    global $databaseConnection;
    $sqlFetch = "SELECT COUNT(*) FROM admins";
    $sqlFetchQuery = $databaseConnection->query($sqlFetch);
    $totalRows = $sqlFetchQuery->fetch();
    $totalRowsStringConverstion = array_shift($totalRows);
    echo $totalRowsStringConverstion;
  }

  function TotalComments(){
    global $databaseConnection;
    $sqlFetch = "SELECT COUNT(*) FROM comments";
    $sqlFetchQuery = $databaseConnection->query($sqlFetch);
    $totalRows = $sqlFetchQuery->fetch();
    $totalRowsStringConverstion = array_shift($totalRows);
    echo $totalRowsStringConverstion;
  }

  function ApprovedCommentsCount($postID) {
      global $databaseConnection;
      $sqlFetchApproved = "SELECT COUNT(*) FROM comments WHERE post_id='$postID' AND status='ON'";
      $sqlFetchApprovedQuery = $databaseConnection->query($sqlFetchApproved);
      $totalCountApproved = $sqlFetchApprovedQuery->fetch();
      $totalCountApprovedStringConversion = array_shift($totalCountApproved);
      return $totalCountApprovedStringConversion;
  }

  function DisApprovedCommentsCount($postID) {
    global $databaseConnection;
    $sqlFetchDisApproved = "SELECT COUNT(*) FROM comments WHERE post_id='$postID' AND status='OFF'";
    $sqlFetchDisApprovedQuery = $databaseConnection->query($sqlFetchDisApproved);
    $totalCountDisApproved = $sqlFetchDisApprovedQuery->fetch();
    $totalCountDisApprovedStringConversion = array_shift($totalCountDisApproved);
    return $totalCountDisApprovedStringConversion;
  }



 ?>
