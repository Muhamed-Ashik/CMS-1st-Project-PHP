<div style="background-color: #24aae1; height: 10px;"></div>
  <footer class="bg-dark text-white py-2">
    <div class="container">
      <div class="row">
        <div class="col">
          <p class="lead text-center">Theme by | Mohamed Ashik | <span id="year"></span> &copy; ----All right Reserved</p>
          <p class="text-center small">This site is only can be used to by
            <a href="#" class="text-primary">ANS Company</a> where they have all the rights.
            No one is allow to distribute copies other that <a href="#" class="text-primary">ANS Company</a>
          </p>
        </div>
      </div>
    </div>
  </footer>
  <div style="background-color: #24aae1; height: 10px;"></div>
