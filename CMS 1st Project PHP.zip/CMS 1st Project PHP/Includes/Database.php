<?php

// $databaseConnection = new PDO(DSN=Data Source Network);
$DataSourceNetwork = "mysql:host=localhost;dbname=cms_1st_project";
$databaseConnection = new PDO($DataSourceNetwork, "root","");

?>
