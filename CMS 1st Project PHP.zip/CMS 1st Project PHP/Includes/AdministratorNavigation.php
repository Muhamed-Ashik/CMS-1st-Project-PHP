
      <div style="background-color: #27aae1; height: 10px;"></div>
      <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
      <div class="container">
        <a href="#" class="navbar-brand">ANS.COM</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapseNavbarCMS">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapseNavbarCMS">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="MyProfile.php" class="nav-link"><i class="fas fa-user text-success"></i> MyProfile</a>
          </li>
          <li class="nav-item">
            <a href="Dashboard.php" class="nav-link">Dashboard</a>
          </li>
          <li class="nav-item">
            <a href="Posts.php" class="nav-link">Posts</a>
          </li>
          <li class="nav-item">
            <a href="Categories.php" class="nav-link">Categories</a>
          </li>
          <li class="nav-item">
            <a href="AddNewAdmin.php" class="nav-link">Manage Admins</a>
          </li>
          <li class="nav-item">
            <a href="Comments.php" class="nav-link">Comments</a>
          </li>
          <li class="nav-item">
            <a href="Blog.php?page=1" class="nav-link" target="_blank">Live Blog</a>
          </li>
        </ul>

        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="Logout.php" class="nav-link text-danger"><i class="fas fa-user-times"></i> Logout</a>
          </li>
        </ul>

        </div><!-- END OF THE NAVBAR COLLAPSE DIV-->
      </div> <!--END OF THE CONTAINER DIV-->
    </nav>
    <div style="background-color: #27aae1; height: 10px;"></div>
