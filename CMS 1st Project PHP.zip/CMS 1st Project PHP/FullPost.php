<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php $seachQueryParameter = $_GET["id"]; ?>


<?php

if(isset($_POST["Submit"])) {

  $commentorName = $_POST["CommentorName"];
  $commentorEmail = $_POST["CommentorEmail"];
  $commentorThoughts = $_POST["CommentorThoughts"];

  date_default_timezone_set("Asia/Colombo");
  $currentTime = time();
  $currentDateTime = strftime("%B-%d-%d %H:%M:%S", $currentTime);

  if(empty($commentorName) || empty($commentorEmail) || empty($commentorThoughts)) {
    $_SESSION["ErrorMessage"] = "All fields must be filled out";
    Redirect_to("FullPost.php?id={$seachQueryParameter}");
  } elseif (strlen($commentorThoughts) > 500) {
    $_SESSION["ErrorMessage"] = "Comment length should be less than 500 characters";
    Redirect_to("FullPost.php?id={$seachQueryParameter}");
  } else {
    // Insert query to insert the data to the comments db
    $sqlInsert = "INSERT INTO comments(datetime, name, email, comment, approvedby, status, post_id) VALUES (:datetimE, :namE, :emaiL, :commenT, 'Pending', 'OFF', :postIdFromUrl)";
    $sqlInsertPrepare = $databaseConnection->prepare($sqlInsert);
    $sqlInsertPrepare->bindValue(':datetimE', $currentDateTime);
    $sqlInsertPrepare->bindValue(':namE', $commentorName);
    $sqlInsertPrepare->bindValue(':emaiL', $commentorEmail);
    $sqlInsertPrepare->bindValue(':commenT', $commentorThoughts);
    $sqlInsertPrepare->bindValue(':postIdFromUrl', $seachQueryParameter);
    $sqlExecute = $sqlInsertPrepare->execute();

    if($sqlExecute) {
      $_SESSION["SuccessMessage"] = "Comment Submitted Succesfully";
      Redirect_to("FullPost.php?id={$seachQueryParameter}");
    } else {
      $_SESSION["ErrorMessage"] = "Something Went Wrong in Comment | Try Again";
      Redirect_to("FullPost.php?id={$seachQueryParameter}");
    }

  }

} // END OF THE SUBMIT BUTTON IF

 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Full Post Page</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Style.css">

    <style media="screen">
      .categories {
        font-family: Bitter, Georgia, "Times New Roman", Times, serif;
        font-weight: bold;
        color: #005E90;
      }

      .categories:hover{
        color: #0090DB;
      }

    </style>

  </head>
  <body>

    <!-- START OF THE NAVIGATION BAR -->

      <div style="background-color: #27aae1; height: 10px;"></div>
      <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
      <div class="container">
        <a href="#" class="navbar-brand">ANS.COM</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapseNavbarCMS">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapseNavbarCMS">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="#" class="nav-link">Home</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">About Us</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">Blog</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">Contact Us</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">Features</a>
          </li>
        </ul>

        <ul class="navbar-nav">
          <form class="form-inline d-none d-sm-block" action="Blog.php">
            <div class="form-group">
              <input type="text" name="Search" placeholder="Search Here" class="form-control mr-2"/>
              <button class="btn btn-primary"  name="SearchButton">Go</button>
            </div>
          </form>
        </ul>

        </div><!-- END OF THE NAVBAR COLLAPSE DIV-->
      </div> <!--END OF THE CONTAINER DIV-->
    </nav>
    <div style="background-color: #27aae1; height: 10px;"></div>

    <!-- END OF THE NAVIGATION BAR -->

    <!-- START OF THE HEADER -->

    <section class="container">
      <div class="row mt-4">
        <div class="col-sm-8">
          <h1>The Complete Responsive CMS Blog</h1>
          <h1 class="lead">The Complete by Blog Using PHP by Mohamed Ashik</h1>

          <?php
           echo ErrorMessage();
           echo SuccessMessage();
           ?>

          <?php
          global $databaseConnection;

          if(isset($_GET["SearchButton"])) {
            // fetch the search result
            $search = $_GET["Search"];
            $sqlSearchFetch = "SELECT * FROM posts WHERE
              datetime LIKE :search OR
              title LIKE :search OR
              category LIKE :search OR
              postdescription LIKE :search";
            $sqlFetchQuery = $databaseConnection->prepare($sqlSearchFetch);
            $sqlFetchQuery->bindValue(':search', '%' . $search . '%');
            $sqlFetchQuery->execute();

          } else {
            $idFromUrl = $_GET["id"];

            if(!isset($idFromUrl)) {
              $_SESSION["ErrorMessage"] = "Bad Request | Try Again...";
              Redirect_to("Blog.php");
            }

            $sqlFetch = "SELECT * FROM posts WHERE id='$idFromUrl'";
            $sqlFetchQuery = $databaseConnection->query($sqlFetch);
            $rowCountResult = $sqlFetchQuery->rowcount();
            if($rowCountResult != 1) {
              $_SESSION["ErrorMessage"] = "Bad Request !";
              Redirect_to("Blog.php");
            }

          }

          while($dataRows = $sqlFetchQuery->fetch()) {
            $id = $dataRows["id"];
            $dateTime = $dataRows["datetime"];
            $title = $dataRows["title"];
            $category = $dataRows["category"];
            $author = $dataRows["author"];
            $image = $dataRows["image"];
            $postDescription = $dataRows["postdescription"];

           ?>

           <div class="card">
             <img src="Uploads/<?php echo $image; ?>" class="img-fluid" style="max-height: 600px; ">;
             <div class="card-body">
               <h4 class="card-title"><?php echo htmlentities($title); ?></h4>
               <small class="text-muted">Category: <span class="text-dark"><?php echo $category; ?></span> & Written by <span class="text-dark"><?php echo htmlentities($author); ?></span> On <span class="text-dark"><?php echo htmlentities($dateTime); ?></span></small>
               <span style="float:right;" class="badge badge-dark text-light">Comments: <?php echo ApprovedCommentsCount($id); ?></span>
               <hr>
               <p class="card-text"><?php echo htmlentities($postDescription); ?></p>
             </div><!--END OF THE CARD BODY-->
           </div><!--END OF THE CARD-->

         <?php } ?>

         <!-- START OF THE COMMENT PART -->
         <br>
         <span class="fieldInfo">Comment</span><br><br>

         <?php

         global $databaseConnection;
         $sqlFetch = "SELECT * FROM comments WHERE post_id='$seachQueryParameter' AND status='ON'";
         $sqlFetchQuery = $databaseConnection->query($sqlFetch);
         while($dataRows = $sqlFetchQuery->fetch()) {

           $dateTime = $dataRows["datetime"];
           $name = $dataRows["name"];
           $comment = $dataRows["comment"];

          ?>

         <div class="media mb-2" style="background-color: #F6F7F9;">
           <img src="images/comment_profile.png" class="img-fluid align-self-start" style="width: 100px;">
           <div class="media-body ml-2 mt-2">
             <h6 class="lead"><?php echo $name; ?></h6>
             <p class="small"><?php echo $dateTime; ?></p>
             <p><?php echo $comment; ?></p>
           </div>
         </div>

       <?php } ?>

         <div class="">
           <form class="" action="FullPost.php?id=<?php echo $seachQueryParameter; ?>" method="post">
             <div class="card mb-3">
               <div class="card-header">
                 <h5 class="fieldInfo">Share your thoughts about this post</h5>
               </div><!--END OF THE CARD-HEADER DIV-->
               <div class="card-body">

                 <div class="form-group">
                   <div class="input-group">
                     <div class="input-group-prepend">
                       <span class="input-group-text"> <i class="fas fa-user"></i> </span>
                     </div>
                     <input type="text" name="CommentorName" placeholder="Name" class="form-control"/>
                   </div><!--END OF THE INPUT GROUP-->
                 </div><!--END OF THE FORM-GROUP-->

                 <div class="form-group">
                   <div class="input-group">
                     <div class="input-group-prepend">
                       <span class="input-group-text"> <i class="fas fa-envelope"></i> </span>
                     </div>
                     <input type="email" name="CommentorEmail" placeholder="Email" class="form-control"/>
                   </div><!--END OF THE INPUT GROUP-->
                 </div><!--END OF THE FORM-GROUP-->

                 <div class="form-group">
                   <textarea class="form-control" name="CommentorThoughts" rows="6" cols="80"></textarea>
                 </div><!--END OF THE FORM-GROUP -->

                 <div class="">
                   <button type="submit" name="Submit" class="btn btn-primary">Submit</button>
                 </div>

               </div><!--END OF THE CARD-BODY-->
             </div><!--END OF THE CARD DIV-->
           </form>
         </div>

         <!-- END OF thE COMMENT PART -->

        </div><!--END OF THE col-sm-8 div-->
        <!-- START OF THE RIGHT SIDE AREA -->
        <div class="col-sm-4">
          <div class="card mb-4">
            <div class="card-body">
              <img src="Images/CodingForKids.jfif" alt="" class="img-fluid d-block mb-4" style="width: 100%;">
              <div class="">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                 Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                  Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                  Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
              </div>
            </div><!--END OF THE CARD-BODYS-->
          </div><!--END OF THE CARD DIV-->

          <div class="card mb-4">
            <div class="card-header bg-dark text-light">
              <h2 class="lead">Sign Up !</h2>
            </div>
            <div class="card-body">
              <button type="button" name="button" class="btn btn-success btn-block mb-3">Join The Forum</button>
              <button type="button" name="button" class="btn btn-danger btn-block mb-3">Login</button>
              <div class="input-group">
                <input type="email" placeholder="Enter the email" class="form-control"/>
                <div class="input-group-append">
                  <button type="button" name="button" class="btn btn-primary btn-sm btn-block">Subscribe Now</button>
                </div><!--END OF THE INPUT-GROUP-APPEND-->
              </div><!--END OF THE INPUT-GROUP-->
            </div><!--END OF THE CARD-BODY-->
          </div><!--END OF THE CARD DIV-->

          <div class="card mb-4">
            <div class="card-header bg-dark text-light">
              <h2 class="lead">Categories</h2>
            </div>
            <div class="card-body">
              <?php
                global $databaseConnection;
                $sqlFetchCategory = "SELECT * FROM category ORDER BY id desc";
                $sqlFetchCategoryQuery = $databaseConnection->query($sqlFetchCategory);
                while($dataRows = $sqlFetchCategoryQuery->fetch()) {
                  $categoryID = $dataRows["id"];
                  $categoryTitle  = $dataRows["title"];
               ?>

               <a href="Blog.php?category=<?php echo $categoryTitle; ?>" target="_blank"><span class="d-block categories"><?php echo $categoryTitle; ?></span></a>

               <?php }// END OF THE WHILE LOOP ?>
            </div><!--END OF THE CARD-BODY-->
          </div><!--END OF THE CARD-->

          <div class="card">
            <div class="card-header bg-dark text-light">
              <h2 class="lead">Recent Posts</h2>
            </div>
            <div class="card-body">
              <?php
                global $databaseConnection;
                $sqlFetchPosts = "SELECT * FROM posts ORDER BY id desc LIMIT 0,5";
                $sqlFetchPostsQuery = $databaseConnection->query($sqlFetchPosts);
                while($dataRows = $sqlFetchPostsQuery->fetch()) {
                  $postID = $dataRows["id"];
                  $postTitle = $dataRows["title"];
                  $postAddedDateTime = $dataRows["datetime"];
                  $postImage = $dataRows["image"];
               ?>
              <div class="media">
                <img src="Uploads/<?php echo $postImage; ?>" class="img-fluid d-block mr-2" width="120" height="90">
                <div class="media-body">
                  <a href="FullPost.php?id=<?php echo $postID; ?>" class="text-dark" target="_blank"><h6><?php echo $postTitle; ?></h6></a>
                  <p class="small"><?php echo $postAddedDateTime; ?></p>
                </div>
              </div>

              <hr>

              <?php } // END OF THE WHILE LOOP ?>

            </div>
          </div>

        </div><!--END OF THE COL-SM-4 DIV -->
        <!-- END OF THE RIGHT SIDE AREA -->

      </div><!--END OF THW ROW DIV-->
    </section>

    <!-- END OF THE HEADER -->

    <br>

    <!-- START OF THE FOOTER -->

    <?php require_once("Includes/Footer.php"); ?>

    <!-- END OF THE FOOTER -->


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <script type="text/javascript">
      $('#year').text(new Date().getFullYear());
    </script>

  </body>
</html>
