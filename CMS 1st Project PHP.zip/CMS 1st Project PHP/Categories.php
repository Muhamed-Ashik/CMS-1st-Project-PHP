<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php
  $_SESSION["TrackingURL"] = $_SERVER["PHP_SELF"];
  Confirm_Login();
 ?>

<?php
  if(isset($_POST["Submit"])) {
    $categoryTitle = $_POST["CategoryTitle"];
    $admin = $_SESSION["userName"];

    date_default_timezone_set("Asia/Colombo"); // timezone location
    $currentTime = time();
    $currentDateTime = strftime("%B-%d-%d %H:%M:%S", $currentTime);

    if(empty($categoryTitle)){
      $_SESSION["ErrorMessage"] = "All fields must be filled out";
      Redirect_to("Categories.php");
    } elseif(strlen($categoryTitle) < 3){
      $_SESSION["ErrorMessage"] = "Category Title should be greater than 2 characters";
    } elseif(strlen($categoryTitle) > 49){
      $_SESSION["ErrorMessage"] = "Category Title should be less than 50 characters";
    } else{
      // Query to insert the data
      $sqlInsert = "INSERT INTO category(title, author, datetime) VALUES (:categoryName, :adminName, :dateTime)";
      $sqlInsertPrepare = $databaseConnection->prepare($sqlInsert);
      $sqlInsertPrepare->bindValue(':categoryName', $categoryTitle);
      $sqlInsertPrepare->bindValue(':adminName', $admin);
      $sqlInsertPrepare->bindValue(':dateTime', $currentDateTime);
      $sqlInsertExecute = $sqlInsertPrepare->execute();

      if($sqlInsertExecute) {
        $_SESSION["SuccessMessage"] = "Category with id: ". $databaseConnection->lastInsertId()." Succesfully Added";
        Redirect_to("Categories.php");
      } else {
        $_SESSION["ErrorMessage"] = "Something went wrong";
        Redirect_to("Categories.php");
      }

    }

  } /*END OF THE SUBMIT BUTTON IF*/
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Categories</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Style.css">
  </head>
  <body>

    <!-- START OF THE NAVIGATION BAR -->

    <?php require_once("Includes/AdministratorNavigation.php"); ?>

    <!-- END OF THE NAVIGATION BAR -->

    <!-- START OF THE HEADER -->

    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1><i class="fas fa-edit" style="color: #27aae1;"></i>Manage Categories</h1>
          </div>
        </div>
      </div>
    </header>

    <!-- END OF THE HEADER -->

    <!-- START OF THE MAIN AREA -->

    <section class="container py-2 mt-4 mb-4" style="min-height: 710px;">
      <div class="row">
        <div class="offset-lg-1 col-lg-10">
          <?php
          echo ErrorMessage();
          echo SuccessMessage();

           ?>
          <form action="Categories.php" method="post">
            <div class="card bg-secondary text-light mb-3">
              <div class="card-header">
                <h1>Add New Category</h1>
              </div>
              <div class="card-body bg-dark">
                <div class="form-group">
                  <label for="title"><span class="fieldInfo" style="font-size: 1.2em; color: rgb(251, 174, 44); font-family: Bitter,Georgia,'Times New Roman',Times,Serif">Category Title:</span></label>
                  <input type="text" name="CategoryTitle" id="title" value="" placeholder="Type the title here" class="form-control"/>
                </div><!--END OF THE FORM-GROUP -->

                <div class="row">
                  <div class="col-lg-6 mb-2">
                    <a href="Dashboard.php" class="btn btn-warning btn-block"><i class="fas fa-arrow-left"></i> Back To Dashboard</a>
                  </div>
                  <div class="col-lg-6 mb-2">
                    <button type="submit" name="Submit" class="btn btn-success btn-block"><i class="fas fa-check"></i> Publish</button>
                  </div>
                </div>

              </div><!--END OF THE CARD-BODY-->
            </div><!--END OF THE CARD-->
          </form>

          <hr class="mt-5">

          <!-- CATEGORY DELETING SECION -->
          <h2 class="py-2">Existing Category</h2>
          <table class="table table-striped">
            <thead class="table-dark">
              <tr>
                <th>No</th>
                <th>Date & Time</th>
                <th>Category Name</th>
                <th>Creator Name</th>
                <th>Action</th>
              </tr>
            </thead>

            <?php

            global $databaseConnection;
            $loopCount = 0;
            $sqlFetch = "SELECT * FROM category ORDER BY id desc";
            $sqlQueryExecute = $databaseConnection->query($sqlFetch);
            while($dataRows = $sqlQueryExecute->fetch()) {
              $categoryID = $dataRows["id"];
              $categoryDateTime = $dataRows["datetime"];
              $categoryName = $dataRows["title"];
              $categoryCreatorName = $dataRows["author"];
              $loopCount++;


             ?>

            <tbody>
              <tr>
                <td><?php echo $loopCount; ?></td>
                <td><?php echo $categoryDateTime; ?></td>
                <td><?php echo $categoryName; ?></td>
                <td><?php echo $categoryCreatorName; ?></td>
                <td><a href="DeleteCategory.php?id=<?php echo $categoryID; ?>" class="btn btn-danger btn-sm">Delete</a></td>
              </tr>
            </tbody>

            <?php } // END OF THE WHILE LOOP ?>

          </table>

        </div><!--END OF THE OFFSET-->
      </div><!--END OF THE ROW-->
    </section>

    <!-- END OF THE MAIN AREA -->

    <!-- START OF THE FOOTER -->

    <?php require_once("Includes/Footer.php"); ?>

    <!-- END OF THE FOOTER -->


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <script type="text/javascript">
      $('#year').text(new Date().getFullYear());
    </script>

  </body>
</html>
