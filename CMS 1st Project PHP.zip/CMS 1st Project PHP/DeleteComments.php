<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php Confirm_Login(); ?>

<?php

  if(isset($_GET["id"])) {
    $searchQueryParameter = $_GET["id"];
    global $databaseConnection;
    $sqlDelete = "DELETE FROM comments WHERE id='$searchQueryParameter'";
    $sqlExecute = $databaseConnection->query($sqlDelete);

    if($sqlExecute) {
      $_SESSION["SuccessMessage"] = "Comment Deleted Succesfully";
      Redirect_to("Comments.php");
    } else {
      $_SESSION["ErrorMessage"] = "Someting Went Wrong on Deleteing Comment | Try Again";
      Redirect_to("Comments.php");
    }

  }
 ?>
