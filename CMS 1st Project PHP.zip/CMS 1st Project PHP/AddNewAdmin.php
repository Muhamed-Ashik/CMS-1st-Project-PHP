<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php
  $_SESSION["TrackingURL"] = $_SERVER["PHP_SELF"];
  Confirm_Login();
 ?>

<?php
  if(isset($_POST["Submit"])) {

    $username = $_POST["Username"];
    $name = $_POST["Name"];
    $password = $_POST["Password"];
    $confirmPassword = $_POST["ConfirmPassword"];

    $admin = $_SESSION["userName"];

    date_default_timezone_set("Asia/Colombo"); // timezone location
    $currentTime = time();
    $currentDateTime = strftime("%B-%d-%d %H:%M:%S", $currentTime);

    if(empty($username) || empty($password) || empty($confirmPassword)){
      $_SESSION["ErrorMessage"] = "All fields must be filled out";
      Redirect_to("AddNewAdmin.php");
    } elseif(strlen($password) < 4){
      $_SESSION["ErrorMessage"] = "Password should be greater than 4 literals";
      Redirect_to("AddNewAdmin.php");
    } elseif($password !== $confirmPassword){
      $_SESSION["ErrorMessage"] = "Password doesn't match";
      Redirect_to("AddNewAdmin.php");
    } elseif(CheckUserNameExistsOrNot($username)) {
      $_SESSION["ErrorMessage"] = "Username Exists | Try Again...";
      Redirect_to("AddNewAdmin.php");
    } else{
      // Query to insert the new admin to db
      global $databaseConnection;
      $sqlInsert = "INSERT INTO admins (datetime, username, password, adminname, addedby) VALUES (:datetimE, :usernamE, :passworD, :adminnamE, :addedbY)";
      $sqlInsertPrepare = $databaseConnection->prepare($sqlInsert);
      $sqlInsertPrepare->bindValue(':datetimE', $currentDateTime);
      $sqlInsertPrepare->bindValue(':usernamE', $username);
      $sqlInsertPrepare->bindValue(':passworD', $password);
      $sqlInsertPrepare->bindValue(':adminnamE', $name);
      $sqlInsertPrepare->bindValue(':addedbY', $admin);
      $sqlExecute = $sqlInsertPrepare->execute();

      if($sqlExecute) {
        $_SESSION["SuccessMessage"] = "New Admin Successfully Added";
        Redirect_to("AddNewAdmin.php");
      } else {
        $_SESSION["ErrorMessage"] = "Admin Not Added";
        Redirect_to("AddNewAdminphp");
      }


    } // END OF THE ELSE MAIN

  } /*END OF THE SUBMIT BUTTON IF*/
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Manage Admins</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Style.css">
  </head>
  <body>

    <!-- START OF THE NAVIGATION BAR -->

      <?php require_once("Includes/AdministratorNavigation.php"); ?>

    <!-- END OF THE NAVIGATION BAR -->

    <!-- START OF THE HEADER -->

    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1><i class="fas fa-edit" style="color: #27aae1;"></i>Manage Admins</h1>
          </div>
        </div>
      </div>
    </header>

    <!-- END OF THE HEADER -->

    <!-- START OF THE MAIN AREA -->

    <section class="container py-2 mb-4 mt-4">
      <div class="row">
        <div class="offset-lg-1 col-lg-10" style="min-height: 300px;">
          <?php
          echo ErrorMessage();
          echo SuccessMessage();

           ?>
          <form action="AddNewAdmin.php" method="post" enctype="multipart/form-data">
            <div class="card bg-secondary text-light mb-3">
              <div class="card-header">
                <h1>Add New Admin</h1>
              </div>
              <div class="card-body bg-dark">

                <div class="form-group">
                  <label for="username"><span class="fieldInfo">Username:</span></label>
                  <input type="text" name="Username" id="usrname" value="" class="form-control"/>
                </div><!--END OF THE FORM-GROUP -->

                <div class="form-group">
                  <label for="name"><span class="fieldInfo">Name: </span></label>
                  <input type="text" name="Name" id="name" class="form-control"/>
                  <small class="text-danger">*Optional</small>
                </div>

                <div class="form-group">
                  <label for="password"><span class="fieldInfo">Password: </span></label>
                  <input type="password" name="Password" id="password" class="form-control"/>
                </div>

                <div class="form-group">
                  <label for="confirmPassword"><span class="fieldInfo">Confirm Password: </span></label>
                  <input type="password" name="ConfirmPassword" id="condfirmPassword" class="form-control"/>
                </div>

                <div class="row">
                  <div class="col-lg-6 mb-2">
                    <a href="Dashboard.php" class="btn btn-warning btn-block"><i class="fas fa-arrow-left"></i> Back To Dashboard</a>
                  </div>
                  <div class="col-lg-6 mb-2">
                    <button type="submit" name="Submit" class="btn btn-success btn-block"><i class="fas fa-check"></i> Publish</button>
                  </div>
                </div>

              </div><!--END OF THE CARD-BODY-->
            </div><!--END OF THE CARD-->
          </form>

          <hr class="mt-5">

          <!-- DELETE EXISTING ADMIN SECTION -->
          <h2 class="py-2">Existing Admins</h2>
          <table class="table table-striped">
            <thead class="table-dark">
              <tr>
                <th>No</th>
                <th>Date & Time</th>
                <th>Username</th>
                <th>Admin Name</th>
                <th>Added By</th>
                <th>Action</th>
              </tr>
            </thead>

            <?php

            global $databaseConnection;
            $loopCount = 0;
            $sqlFetch = "SELECT * FROM admins ORDER BY id desc";
            $sqlFetchQuery = $databaseConnection->query($sqlFetch);
            while($dataRows =  $sqlFetchQuery->fetch()) {
              $adminID = $dataRows["id"];
              $adminAddedDateTime = $dataRows["datetime"];
              $adminUsername = $dataRows["username"];
              $adminName = $dataRows["adminname"];
              $adminAddedBy = $dataRows["addedby"];
              $loopCount++;
             ?>

            <tbody>
              <tr>
                <td><?php echo $loopCount; ?></td>
                <td><?php echo $adminAddedDateTime; ?></td>
                <td><?php echo $adminUsername; ?></td>
                <td><?php echo $adminName; ?></td>
                <td><?php echo $adminAddedBy; ?></td>
                <td><a href="DeleteAdmin.php?id=<?php echo $adminID; ?>" class="btn btn-danger">Delete</a></td>
              </tr>
            </tbody>

            <?php } // END OF THE WHILE LOOP ?>

          </table>

        </div><!--END OF THE OFFSET-->
      </div><!--END OF THE ROW-->
    </section>

    <!-- END OF THE MAIN AREA -->

    <!-- START OF THE FOOTER -->

    <?php require_once("Includes/Footer.php"); ?>

    <!-- END OF THE FOOTER -->


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <script type="text/javascript">
      $('#year').text(new Date().getFullYear());
    </script>

  </body>
</html>
