<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php"); ?>
<?php
  $_SESSION["TrackingURL"] = $_SERVER["PHP_SELF"];
  Confirm_Login();
 ?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Style.css">
    <title>Posts</title>
  </head>
  <body>

    <!-- START OF THE NAVIGATION BAR -->

    <?php require_once("Includes/AdministratorNavigation.php"); ?>

    <!-- END OF THE NAVIGATION BAR -->

    <!-- START OF THE HEADER -->

    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1><i class="fas fa-blog" style="color: #27aae1;"></i> Blog Posts</h1>
          </div><!--END OF THE COL-MD-12 -->

          <div class="col-md-3">
            <a href="AddNewPosts.php" class="btn btn-primary btn-block mb-2">
              <i class="fas fa-edit"></i> Add New Posts
            </a>
          </div>

          <div class="col-md-3">
            <a href="Categories.php" class="btn btn-info btn-block mb-2">
              <i class="fas fa-folder-plus"></i> Add Category
            </a>
          </div>

          <div class="col-md-3">
            <a href="AddNewAdmin.php" class="btn btn-warning btn-block mb-2">
              <i class="fas fa-user-plus"></i> Add New Admin
            </a>
          </div>

          <div class="col-md-3">
            <a href="Comments.php" class="btn btn-success btn-block mb-2">
              <i class="fas fa-check"></i> Approve Comments
            </a>
          </div>

        </div><!--END OF THE ROW-->
      </div><!--END OF THE CONTAINER-->
    </header>

    <!-- END OF THE HEADER -->



    <!-- START OF THE MAIN AREA -->

    <section class="container mt-4 mb-4 py-2" style="min-height: 595px;">
      <div class="row">
        <div class="col-lg-12">
          <?php

            echo ErrorMessage();
            echo SuccessMessage();

          ?>
          <table class="table table-striped table-hover">
            <thead class="thead-dark">
              <tr>
                <th>#</th>
                <th>Title</th>
                <th>Category</th>
                <th>Date & Time</th>
                <th>Author</th>
                <th>Banner</th>
                <th>Comments</th>
                <th>Action</th>
                <th>Live Preview</th>
              </tr>
            </thead>

            <?php

            global $databaseConnection;
            $sqlFetch = "SELECT * FROM posts ORDER BY id desc";
            $sqlFetchQuery = $databaseConnection->query($sqlFetch);
            $tableIndex = 0;
            while($dataRows = $sqlFetchQuery->fetch()) {
              $id = $dataRows["id"];
              $dateTime = $dataRows["datetime"];
              $postTitle = $dataRows["title"];
              $category = $dataRows["category"];
              $admin = $dataRows["author"];
              $image = $dataRows["image"];
              $postDescription = $dataRows["postdescription"];
              $tableIndex++;

             ?>
             <tbody>
               <tr>
                 <td><?php echo $tableIndex; ?></td>
                 <td>
                   <?php if(strlen($postTitle>20)) {
                     $postTitle = substr($postTitle,0,18).'...';
                   }
                      echo $postTitle; ?>
                  </td>

                 <td>
                   <?php if(strlen($category>8)) {
                     $category = substr($category,0,8).'...';
                   }
                    echo $category; ?>
                  </td>

                 <td>
                   <?php if(strlen($dateTime>11)) {
                     $dateTime = substr($dateTime,0,11).'...';
                   }
                    echo $dateTime; ?>
                  </td>

                 <td>
                   <?php if(strlen($admin>6)) {
                     $admin = substr($admin,0,6).'...';
                   } ?>
                   <?php echo $admin; ?></td>
                 <td><img src="Uploads/<?php echo $image; ?>" width="120px"></td>
                 <td>
                   <span class="badge badge-success">
                     <?php echo ApprovedCommentsCount($id); ?>
                   </span>
                   <span class="badge badge-danger">
                     <?php echo DisApprovedCommentsCount($id); ?>
                   </span>
                 </td>
                 <td>
                    <a href="EditPost.php?id=<?php echo $id; ?>"><span class="btn btn-warning btn-sm">Edit</span></a>
                    <a href="DeletePost.php?id=<?php echo $id; ?>"><span class="btn btn-danger btn-sm">Delete</span></a>
                 </td>
                 <td>
                   <a href="FullPost.php?id=<?php echo $id; ?>" target="_blank"><span class="btn btn-primary btn-sm">Live Preview</span></a>
                 </td>
               </tr>
             </tbody>

           <?php } ?>

          </table>
        </div>
      </div>
    </section>

    <!-- END OF THE MAIN AREA -->

    <!-- START OF THE FOOTER -->

    <?php require_once("Includes/Footer.php"); ?>

    <!-- END OF THE FOOTER -->


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <script type="text/javascript">
      $('#year').text(new Date().getFullYear());
    </script>

  </body>
  </html>
