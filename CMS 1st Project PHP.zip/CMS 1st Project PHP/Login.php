<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php

  if(isset($_SESSION["userId"])) {
    Redirect_to("Dashboard.php");
  }

 ?>
<?php

  if(isset($_POST["Submit"])) {
    $username = $_POST["Username"];
    $password = $_POST["Password"];

    if(empty($username) || empty($password)) {
      $_SESSION["ErrorMessage"] = "All fields must be filled out";
      Redirect_to("Login.php");
    } else {
      // Query to fetch the records

    $accountFound=Login_Attempt($username, $password);
    if($accountFound) {

      $_SESSION["userId"]    = $accountFound["id"];
      $_SESSION["userName"]  = $accountFound["username"];
      $_SESSION["adminName"] = $accountFound["adminname"];

      $_SESSION["SuccessMessage"] = "Welcome " . $_SESSION["userName"];

      if(isset($_SESSION["TrackingURL"])) {
         Redirect_to($_SESSION["TrackingURL"]);
      } else {
        Redirect_to("Dashboard.php");
      }

    } else {
      $_SESSION["ErrorMessage"] = "Username / Password Wrong | Try Again !";
      Redirect_to("Login.php");
    }

    }

  }

 ?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Style.css">
  </head>
  <body>

    <!-- START OF THE NAVIGATION BAR -->

      <div style="background-color: #27aae1; height: 10px;"></div>
      <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
      <div class="container">
        <a href="#" class="navbar-brand">ANS.COM</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapseNavbarCMS">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapseNavbarCMS">

        </div><!-- END OF THE NAVBAR COLLAPSE DIV-->
      </div> <!--END OF THE CONTAINER DIV-->
    </nav>
    <div style="background-color: #27aae1; height: 10px;"></div>

    <!-- END OF THE NAVIGATION BAR -->

    <!-- START OF THE HEADER -->

    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1></h1>
          </div>
        </div>
      </div>
    </header>

    <!-- END OF THE HEADER -->

    <!-- START OF THE MAIN AREA -->

    <section class="container py-2 mb-4" style="min-height: 710px;"> 
      <div class="row">
        <div class="offset-sm-3 col-sm-6">
          <br><br><br><br><br><br>

          <?php
            echo SuccessMessage();
            echo ErrorMessage();
          ?>

          <div class="card bg-secondary text-light">
            <div class="card-header">
              <h4>Welcome Back !</h4>
            </div><!--END OF THE CARD-HEADER-->
              <div class="card-body bg-dark">
              <form class="#" action="Login.php" method="post">

                <div class="form-group">
                  <label for=""><span class="fieldInfo">Username: </span></label>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text text-white bg-info"><i class="fas fa-user"></i></span>
                    </div><!--END OF THE INPUT-GRO  UP-PREPEND-->
                    <input type="text" name="Username" class="form-control"/>
                  </div><!--END OF THE INPUT-GROUP DIV-->
                </div><!--END OF THE FORM-GROUP-->

                <div class="form-group">
                  <label for=""><span class="fieldInfo">Password: </span></label>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text text-white bg-info"><i class="fas fa-lock"></i></span>
                    </div>
                    <input type="password" name="Password" class="form-control">
                  </div><!--END OF THE INPUT-GROUP-->
                </div><!--END OF THE FORM_GROUP-->

                <input type="submit" name="Submit" class="btn btn-info btn-block"/>

              </form>
            </div><!--END OF THE CARD-HEADER DIV-->
          </div><!--END OF THE CARD-->
        </div><!--END OF THE COL-SM-6 DIV-->
      </div><!--END OF THE ROW-->
    </section>

    <!-- END OF THE MAIN AREA -->

    <!-- START OF THE FOOTER -->

    <?php require_once("Includes/Footer.php"); ?>

    <!-- END OF THE FOOTER -->


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <script type="text/javascript">
      $('#year').text(new Date().getFullYear());
    </script>

  </body>
</html>
