<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
  <!-- Fetching the data -->
<?php
  $searchQueryParameter = $_GET["username"];
  global $databaseConnection;
  $sqlFetch = "SELECT adminname, adminheadline, adminbio, adminimage FROM admins WHERE username=:userName";
  $sqlFetchPrepare = $databaseConnection->prepare($sqlFetch);
  $sqlFetchPrepare->bindValue(':userName', $searchQueryParameter);
  $sqlFetchPrepare->execute();
  $result = $sqlFetchPrepare->rowcount();
  if($result == 1) {
    // store the fetch result
    while($dataRows = $sqlFetchPrepare->fetch()) {
      $adminName = $dataRows["adminname"];
      $adminHeadline = $dataRows["adminheadline"];
      $adminBio = $dataRows["adminbio"];
      $adminImage = $dataRows["adminimage"];

    } //END OF THE WHILE LOOP

  } else {
    // restriction
    $_SESSION["ErrorMessage"] = "Bad Request !";
    Redirect_to("Blog.php");
  }
 ?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Profile</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Style.css">
  </head>
  <body>

    <!-- START OF THE NAVIGATION BAR -->

      <div style="background-color: #27aae1; height: 10px;"></div>
      <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
      <div class="container">
        <a href="#" class="navbar-brand">ANS.COM</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapseNavbarCMS">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapseNavbarCMS">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="#" class="nav-link">Home</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">About Us</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">Blog</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">Contact Us</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">Features</a>
          </li>
        </ul>

        <ul class="navbar-nav">
          <form class="form-inline d-none d-sm-block" action="Blog.php">
            <div class="form-group">
              <input type="text" name="Search" placeholder="Search Here" class="form-control mr-2"/>
              <button class="btn btn-primary"  name="SearchButton">Go</button>
            </div>
          </form>
        </ul>

        </div><!-- END OF THE NAVBAR COLLAPSE DIV-->

      </div> <!--END OF THE CONTAINER DIV-->
    </nav>
    <div style="background-color: #27aae1; height: 10px;"></div>

    <!-- END OF THE NAVIGATION BAR -->

    <!-- START OF THE HEADER -->

    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1><i class="fas fa-user text-success" style="color: #27aae1;"></i> <?php echo htmlentities($adminName);  ?></h1>
            <h4 class="py-2"><?php echo htmlentities($adminHeadline); ?></h4>
          </div>
        </div>
      </div>
    </header>

    <!-- END OF THE HEADER -->

    <!-- START OF THE MAIN AREA -->
    <section class="container py-2 mt-2 mb-4" style="min-height: 630px;">
      <div class="row">
        <div class="col-md-3">
          <img src="Images/<?php echo htmlentities($adminImage); ?>" alt="Profile Picture" class="img-fluid d-block">
        </div>
        <div class="col-md-9">
          <div class="card mt-5">
            <div class="card-body">
              <p class="lead">
                <?php echo htmlentities($adminBio); ?>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- END OF THE MAIN AREA -->

    <!-- START OF THE FOOTER -->

    <?php require_once("Includes/Footer.php"); ?>

    <!-- END OF THE FOOTER -->


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <script type="text/javascript">
      $('#year').text(new Date().getFullYear());
    </script>

  </body>
</html>
