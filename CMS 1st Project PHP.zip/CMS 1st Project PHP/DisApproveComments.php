<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php Confirm_Login(); ?>

<?php

  if(isset($_GET["id"])) {
    $searchQueryParameter = $_GET["id"];
    $adminUserName = $_SESSION["userName"];
    global $databaseConnection;
    $sqlUpdate = "UPDATE comments SET status='OFF', approvedby='$adminUserName' WHERE id='$searchQueryParameter'";
    $sqlExecute = $databaseConnection->query($sqlUpdate);

    if($sqlExecute) {
      $_SESSION["SuccessMessage"] = "Comment Dis-Approved Succesfully";
      Redirect_to("Comments.php");
    } else {
      $_SESSION["ErrorMessage"] = "Someting Went Wrong on Dis-Approving Comment";
      Redirect_to("Comments.php");
    }

  }

 ?>
