<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php
  $_SESSION["TrackingURL"] = $_SERVER["PHP_SELF"];
  Confirm_Login();
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Comments</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Style.css">
  </head>
  <body>

    <!-- START OF THE NAVIGATION BAR -->

    <?php require_once("Includes/AdministratorNavigation.php"); ?>

    <!-- END OF THE NAVIGATION BAR -->

    <!-- START OF THE HEADER -->

    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1><i class="fas fa-comments" style="color: #27aae1;"></i> Manage Comments</h1>
          </div>
        </div>
      </div>
    </header>

    <!-- END OF THE HEADER -->

    <!-- START OF THE MAIN AREA -->

    <section class="container py-2 mt-4 mb-4" style="min-height: 640px;">
      <div class="row">
        <div class="col-lg-12">

          <?php

            echo SuccessMessage();
            echo ErrorMessage();

           ?>

          <h2 class="pb-2">Un-Approved Comments</h2>
          <table class="table table-striped table-hover">
            <thead class="table-dark">
              <tr>
                <th>No</th>
                <th>Date &  Time</th>
                <th>Name </th>
                <th>Comments</th>
                <th>Approve</th>
                <th>Action</th>
                <th>Details</th>
              </tr>
            </thead>

            <?php

            global $databaseConnection;
            $loopCount = 0;
            $sqlFetch = "SELECT * FROM comments WHERE status='OFF' ORDER BY id desc";
            $sqlFethcQuery = $databaseConnection->query($sqlFetch);
            while($dataRows = $sqlFethcQuery->fetch()) {
              $commentID = $dataRows["id"];
              $commentorName = $dataRows["name"];
              $dataTimeOfComment = $dataRows["datetime"];
              $commentContent = $dataRows["comment"];
              $commentPostID = $dataRows["post_id"];
              $loopCount++;
             ?>

            <tbody>
              <tr>
                <td><?php echo htmlentities($loopCount); ?></td>
                <td><?php echo htmlentities($dataTimeOfComment); ?></td>
                <td><?php echo htmlentities($commentorName); ?></td>
                <td><?php echo htmlentities($commentContent); ?></td>
                <td><a href="ApproveComments.php?id=<?php echo $commentID; ?>" class="btn btn-success btn-sm">Approve</a></td>
                <td><a href="DeleteComments.php?id=<?php echo $commentID; ?>" class="btn btn-danger btn-sm">Delete</a></td>
                <td><a href="FullPost.php?id=<?php echo $commentPostID; ?>" class="btn btn-primary btn-sm" target="_blank" style="min-width: 100px;">Live Preview</a></td>
              </tr>
            </tbody>

            <?php   } // END OF THE WHILE LOOP ?>

          </table>

          <hr class="mt-5">

          <!-- DIS-APPROVE COMMMENTS SECTION -->
           <h2 class="py-2">Approved Comments</h2>
          <table class="table table-striped table-hover">
            <thead class="table-dark">
              <tr>
                <th>No</th>
                <th>Date & Time</th>
                <th>Name</th>
                <th>Comments</th>
                <th>Revert</th>
                <th>Action</th>
                <th>Details</th>
              </tr>
            </thead>

            <?php

            global $databaseConnection;
            $loopCount = 0;
            $sqlFetch = "SELECT * FROM comments WHERE status='ON' ORDER BY id desc";
            $sqlFetchQuery = $databaseConnection->query($sqlFetch);

            while($dataRows = $sqlFetchQuery->fetch()) {
              $commentID = $dataRows["id"];
              $dateTimeOfComment = $dataRows["datetime"];
              $commentorName  = $dataRows["name"];
              $commentContent = $dataRows["comment"];
              $commentPostID = $dataRows["post_id"];
              $loopCount++;

             ?>

            <tbody>
              <tr>
                <td><?php echo $loopCount; ?></td>
                <td><?php echo $dateTimeOfComment; ?></td>
                <td><?php echo $commentorName; ?></td>
                <td><?php echo $commentContent; ?></td>
                <td><a href="DisApproveComments.php?id=<?php echo $commentID; ?>" class="btn btn-warning btn-sm" style="min-width: 100px;">Dis-Approve</a></td>
                <td><a href="DeleteComments.php?id=<?php echo $commentID; ?>" class="btn btn-danger btn-sm">Delete</a></td>
                <td><a href="FullPost.php?id=<?php echo $commentPostID; ?>" class="btn btn-primary btn-sm" target="_blank" style="min-width: 100px;">Live Preview</a></td>
              </tr>
            </tbody>

            <?php     } // END OF THE WHILE LOOP  ?>

          </table>

        </div><!--END OF THE COL-LG-12 DIV -->
      </div><!-- END OF THE ROW -->
    </section>

    <!-- END OF THE MAIN AREA -->

    <!-- START OF THE FOOTER -->

    <?php require_once("Includes/Footer.php"); ?>

    <!-- END OF THE FOOTER -->


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <script type="text/javascript">
      $('#year').text(new Date().getFullYear());
    </script>

  </body>
</html>
