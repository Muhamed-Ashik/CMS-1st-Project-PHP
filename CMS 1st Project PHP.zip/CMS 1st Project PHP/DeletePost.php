<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php Confirm_Login(); ?>

<?php

$searchQueryParameter = $_GET["id"];


// Fetch the records from the posts table
  global $databaseConnection;

  $sqlFetch = "SELECT * FROM posts WHERE id = '$searchQueryParameter'";
  $sqlFetchQuery = $databaseConnection->query($sqlFetch);
  while($dataRows = $sqlFetchQuery->fetch()) {
    $id = $dataRows["id"];
    $title = $dataRows["title"];
    $category = $dataRows["category"];
    $image = $dataRows["image"];
    $postDescription = $dataRows["postdescription"];
  }

// echo $image;

  if(isset($_POST["Submit"])) {

    global $databaseConnection;
    $sqlDelete = "DELETE FROM posts WHERE id = '$searchQueryParameter'";
    $sqlDeleteQuery = $databaseConnection->query($sqlDelete);

    if($sqlDeleteQuery) {
      $imageToBeDeleted = "Uploads/$image"; // find the correct image with the name in the folder
      unlink($imageToBeDeleted); // remove the image in the varibale
      $_SESSION["SuccessMessage"] = "Post Deleted Sucessfully...!";
      Redirect_to("Posts.php");
    } else {
      $_SESSION["ErrorMessage"] = "Something Went Wrong | Try Again...!";
      Redirect_to("Posts.php");
    }

  } /*END OF THE SUBMIT BUTTON IF*/
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Delete Post Page</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Style.css">
  </head>
  <body>

    <!-- START OF THE NAVIGATION BAR -->

    <?php require_once("Includes/AdministratorNavigation.php"); ?>

    <!-- END OF THE NAVIGATION BAR -->

    <!-- START OF THE HEADER -->

    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1><i class="fas fa-edit" style="color: #27aae1;"></i>Delete Post</h1>
          </div>
        </div>
      </div>
    </header>

    <!-- END OF THE HEADER -->

    <!-- START OF THE MAIN AREA -->

    <section class="container py-2 mt-3 mb-3"  style="min-height: 655px;">
      <div class="row">
        <div class="offset-lg-1 col-lg-10">
          <?php


          if(!$id == $searchQueryParameter | empty($searchQueryParameter)) {
            Redirect_to("Posts.php");
          }

           ?>
          <form action="DeletePost.php?id=<?php echo $searchQueryParameter; ?>" method="post" enctype="multipart/form-data">
            <div class="card bg-secondary text-light mb-3">
              <div class="card-body bg-dark">
                <div class="form-group">
                  <label for="title"><span class="fieldInfo" style="font-size: 1.2em; color: rgb(251, 174, 44); font-family: Bitter,Georgia,'Times New Roman',Times,Serif">Post Title: </span></label>
                  <input disabled type="text" name="PostTitle" id="title" placeholder="Type the title here" class="form-control" value="<?php echo $title; ?>"/>
                </div><!--END OF THE FORM-GROUP -->

                <div class="form-group">
                  <span class="fieldInfo">Existing Category: </span><?php echo $category; ?><br>
                  <label for="CategoryTitle"><span class="fieldInfo"  style="font-size: 1.2em; color: rgb(251, 174, 44); font-family: Bitter,Georgia,'Times New Roman',Times,Serif">Choose Category: </span></label>
                  <select disabled class="form-control" name="Category" id="CategoryTitle">
                    <?php
                      global $databaseConnection;
                      $sqlFetch = "SELECT id, title FROM category";
                      $sqlFetchQuery = $databaseConnection->query($sqlFetch);
                      while($dataRows = $sqlFetchQuery->fetch()) {
                        $id = $dataRows["id"];
                        $categoryName = $dataRows["title"];
                     ?>

                     <option><?php echo $categoryName; ?></option>

                     <?php

                      }

                      ?>
                  </select>
                </div><!--END OF THE FORM-GROUP -->

               <div class="form-group">
                  <span class="fieldInfo">Existing Image: </span> <br> <img src="Uploads/<?php echo $image; ?>" height="150px"><br>
                </div>

                <div class="form-group">
                  <label for="description"  style="font-size: 1.2em; color: rgb(251, 174, 44); font-family: Bitter,Georgia,'Times New Roman',Times,Serif">Post Description: </label>
                  <textarea disabled type="text" class="form-control" name="PostDescription" id="description" cols="80" rows="8"><?php echo $postDescription; ?></textarea>
                </div>

                <div class="row">
                  <div class="col-lg-6 mb-2">
                    <a href="Dashboard.php" class="btn btn-warning btn-block"><i class="fas fa-arrow-left"></i> Back To Dashboard</a>
                  </div>
                  <div class="col-lg-6 mb-2">
                    <button name="Submit" class="btn btn-danger btn-block"><i class="fas fa-trash"></i> Delete</button>
                  </div>
                </div>

              </div><!--END OF THE CARD-BODY-->
            </div><!--END OF THE CARD-->
          </form>
        </div><!--END OF THE OFFSET-->
      </div><!--END OF THE ROW-->
    </section>

    <!-- END OF THE MAIN AREA -->

    <!-- START OF THE FOOTER -->

      <?php require_once("Includes/Footer.php"); ?>

    <!-- END OF THE FOOTER -->


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <script type="text/javascript">
      $('#year').text(new Date().getFullYear());
    </script>

  </body>
</html>
