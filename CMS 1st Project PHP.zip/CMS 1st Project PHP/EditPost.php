<?php require_once("Includes/Database.php"); ?>
<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php");?>
<?php Confirm_Login(); ?>

<?php

$searchQueryParameter = $_GET["id"];

  if(isset($_POST["Submit"])) {
    $postTitle = $_POST["PostTitle"];
    $categoryName = $_POST["Category"];
    $image = $_FILES["Image"]["name"]; // image and image name
    $target = "Uploads/". basename($_FILES["Image"]["name"]); // target location
    $postDescription = $_POST["PostDescription"];

    $admin = $_SESSION["userName"];

    date_default_timezone_set("Asia/Colombo"); // timezone location
    $currentTime = time();
    $currentDateTime = strftime("%B-%d-%d %H:%M:%S", $currentTime);

    if(empty($postTitle)){
      $_SESSION["ErrorMessage"] = "All fields must be filled out";
      Redirect_to("Posts.php");
    } elseif(strlen($postTitle) < 5){
      $_SESSION["ErrorMessage"] = "Post Title should be greater than 5 characters";
      Redirect_to("Posts.php");
    } elseif(strlen($postDescription) > 999){
      $_SESSION["ErrorMessage"] = "Post Description should be less than 1000 characters";
      Redirect_to("Posts.php");
    } else{
      // Query to insert the data
      global $databaseConnection;

      if(!empty($_FILES["Image"]["name"])) {
        $sqlUpdate = "UPDATE posts SET datetime='$currentDateTime', title='$postTitle', category='$categoryName', image='$image', postdescription='$postDescription' WHERE id = $searchQueryParameter";
          $sqlUpdateExecute = $databaseConnection->query($sqlUpdate);
      } else {
        $sqlUpdate = "UPDATE posts SET datetime='$currentDateTime', title='$postTitle', category='$categoryName', postdescription='$postDescription' WHERE id = $searchQueryParameter";
        $sqlUpdateExecute = $databaseConnection->query($sqlUpdate);
      }

      // $sqlUpdate = "UPDATE posts SET datetime='$currentDateTime', title='$postTitle', category='$categoryName', image='$image', postdescription='$postDescription' WHERE id = $searchQueryParameter";
      // $sqlUpdateExecute = $databaseConnection->query($sqlUpdate);

      // image uplaoding
      move_uploaded_file($_FILES["Image"]["tmp_name"], $target);

      if($sqlUpdateExecute) {
        $_SESSION["SuccessMessage"] = "Post Succesfully Updated ";
        Redirect_to("Posts.php");
      } else {
        $_SESSION["ErrorMessage"] = "Something Went Wrong | Try Again";
        Redirect_to("Posts.php");
      }


    }

  } /*END OF THE SUBMIT BUTTON IF*/
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit Post Page</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Style.css">
  </head>
  <body>

    <!-- START OF THE NAVIGATION BAR -->

    <?php require_once("Includes/AdministratorNavigation.php"); ?>

    <!-- END OF THE NAVIGATION BAR -->

    <!-- START OF THE HEADER -->

    <header class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1><i class="fas fa-edit" style="color: #27aae1;"></i>Edit Post</h1>
          </div>
        </div>
      </div>
    </header>

    <!-- END OF THE HEADER -->

    <!-- START OF THE MAIN AREA -->

    <section class="container py-2 mb-4">
      <div class="row">
        <div class="offset-lg-1 col-lg-10" style="min-height: 300px;">
          <?php
          echo ErrorMessage();
          echo SuccessMessage();

          // Fetch the records from the posts table
          global $databaseConnection;

          if(empty($searchQueryParameter)) {
            Redirect_to("Posts.php");
          }

          $sqlFetch = "SELECT * FROM posts WHERE id = '$searchQueryParameter'";
          $sqlFetchQuery = $databaseConnection->query($sqlFetch);
          while($dataRows = $sqlFetchQuery->fetch()) {
            $title = $dataRows["title"];
            $category = $dataRows["category"];
            $image = $dataRows["image"];
            $postDescription = $dataRows["postdescription"];
          }

           ?>
          <form action="EditPost.php?id=<?php echo $searchQueryParameter; ?>" method="post" enctype="multipart/form-data">
            <div class="card bg-secondary text-light mb-3">
              <div class="card-body bg-dark">
                <div class="form-group">
                  <label for="title"><span class="fieldInfo" style="font-size: 1.2em; color: rgb(251, 174, 44); font-family: Bitter,Georgia,'Times New Roman',Times,Serif">Post Title: </span></label>
                  <input type="text" name="PostTitle" id="title" placeholder="Type the title here" class="form-control" value="<?php echo $title; ?>"/>
                </div><!--END OF THE FORM-GROUP -->

                <div class="form-group">
                  <span class="fieldInfo">Existing Category: </span><?php echo $category; ?><br>
                  <label for="CategoryTitle"><span class="fieldInfo"  style="font-size: 1.2em; color: rgb(251, 174, 44); font-family: Bitter,Georgia,'Times New Roman',Times,Serif">Choose Category: </span></label>
                  <select class="form-control" name="Category" id="CategoryTitle">
                    <?php
                      global $databaseConnection;
                      $sqlFetch = "SELECT id, title FROM category";
                      $sqlFetchQuery = $databaseConnection->query($sqlFetch);
                      while($dataRows = $sqlFetchQuery->fetch()) {
                        $id = $dataRows["id"];
                        $categoryName = $dataRows["title"];
                     ?>

                     <option><?php echo $categoryName; ?></option>

                     <?php

                      }

                      ?>
                  </select>
                </div><!--END OF THE FORM-GROUP -->

                <div class="form-group">
                  <span class="fieldInfo">Existing Image: </span> <br> <img src="Uploads/<?php echo $image; ?>" height="150px"><br>
                  <label for=""><span class="fieldInfo"  style="font-size: 1.2em; color: rgb(251, 174, 44); font-family: Bitter,Georgia,'Times New Roman',Times,Serif">Select Image: </span></label>
                  <div class="custom-file">
                    <input type="file" name="Image" id="image" class="custom-file-input">
                    <label for="image" class="custom-file-label">Choose Image: </label>
                  </div>
                </div>

                <div class="form-group">
                  <label for="description"  style="font-size: 1.2em; color: rgb(251, 174, 44); font-family: Bitter,Georgia,'Times New Roman',Times,Serif">Post Description: </label>
                  <textarea type="text" class="form-control" name="PostDescription" id="description" cols="80" rows="8"><?php echo $postDescription; ?></textarea>
                </div>

                <div class="row">
                  <div class="col-lg-6 mb-2">
                    <a href="Dashboard.php" class="btn btn-warning btn-block"><i class="fas fa-arrow-left"></i> Back To Dashboard</a>
                  </div>
                  <div class="col-lg-6 mb-2">
                    <button name="Submit" class="btn btn-success btn-block"><i class="fas fa-check"></i> Publish</button>
                  </div>
                </div>

              </div><!--END OF THE CARD-BODY-->
            </div><!--END OF THE CARD-->
          </form>
        </div><!--END OF THE OFFSET-->
      </div><!--END OF THE ROW-->
    </section>

    <!-- END OF THE MAIN AREA -->

    <!-- START OF THE FOOTER -->

    <?php require_once("Includes/Footer.php"); ?>

    <!-- END OF THE FOOTER -->


    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <script type="text/javascript">
      $('#year').text(new Date().getFullYear());
    </script>

  </body>
</html>
