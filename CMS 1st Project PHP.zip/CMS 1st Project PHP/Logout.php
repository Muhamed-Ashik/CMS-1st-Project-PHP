<?php require_once("Includes/Functions.php"); ?>
<?php require_once("Includes/Sessions.php"); ?>

<?php

  $_SESSION["userId"]    = null;
  $_SESSION["userName"]  = null;
  $_SESSION["adminName"] = null;

  session_destroy();

  Redirect_to("Login.php");

 ?>
