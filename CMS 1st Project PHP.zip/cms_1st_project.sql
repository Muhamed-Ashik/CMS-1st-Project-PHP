-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2022 at 05:47 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms_1st_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) NOT NULL,
  `datetime` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `adminname` varchar(30) NOT NULL,
  `adminheadline` varchar(30) NOT NULL,
  `adminbio` varchar(500) NOT NULL,
  `adminimage` varchar(60) NOT NULL DEFAULT '''Avatar.jpg''',
  `addedby` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `datetime`, `username`, `password`, `adminname`, `adminheadline`, `adminbio`, `adminimage`, `addedby`) VALUES
(1, 'January-28-28 20:47:45', 'Mohamed Ashik', '1234', 'M Ashik', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ', 'Avatar.jpg', 'Mohamed Ashik'),
(2, 'January-28-28 20:49:17', 'Ashik', '1234', 'Ashik', 'Software Engineer', 'Hello, I am Mohamed Ashik, Who is a Software Engineer and PHP Backend Developer. ', 'MyProfilePic.jfif', 'Mohamed Ashik'),
(3, 'January-31-31 13:55:31', 'Muhamed Ashik', '1234', 'Ashik', '', '', 'Avatar.jpg', 'Mohamed Ashik'),
(6, 'February-15-15 20:19:37', 'Rizmy Mohamed', '1234', 'Rizmy', '', '', '\'Avatar.jpg\'', 'Ashik');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(10) NOT NULL,
  `title` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `datetime` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `title`, `author`, `datetime`) VALUES
(1, 'Technology', 'Mohamed_Ashik', 'January-21-21 15:03:39'),
(2, 'News', 'Mohamed_Ashik', 'January-21-21 15:05:10'),
(3, 'Fitness', 'Mohamed_Ashik', 'January-21-21 15:05:49'),
(4, 'Sports', 'Mohamed_Ashik', 'January-22-22 14:05:46');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) NOT NULL,
  `datetime` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(60) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `approvedby` varchar(50) NOT NULL,
  `status` varchar(3) NOT NULL,
  `post_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `datetime`, `name`, `email`, `comment`, `approvedby`, `status`, `post_id`) VALUES
(5, 'January-27-27 11:51:31', 'Mohamed Ashik', 'Mohamedashik014@gmail.com', 'Apple 12 is also a nice and best phone to use. which keep the important data as privacy. No one can do it anything.', 'Mohamed Ashik', 'ON', 7),
(10, 'January-27-27 13:00:46', 'Mohamed Ashik', 'Ashik@gmail.com', 'Yah basket ball is really a good game', 'Muhamed Ashik', 'OFF', 15),
(11, 'January-27-27 13:01:15', 'Ashik', 'Ashik@gmail.com', 'Batminton is also a really good game', 'Muhamed Ashik', 'ON', 14),
(13, 'January-27-27 13:04:05', 'Mohamed Ashik', 'Mohamedashik@gmail.com', 'Nice mobile to use. I have one', 'Muhamed Ashik', 'ON', 10),
(16, 'January-27-27 13:42:29', 'Mohamed Ashik', 'Ashik@gmail.com', 'Another comment for the Asus laptop', 'Muhamed Ashik', 'OFF', 9),
(18, 'February-06-06 13:40:44', 'Ashik', 'Ashik@gmail.com', 'Testing Comments Because i am working in Dashboard', 'Muhamed Ashik', 'ON', 15),
(19, 'February-06-06 13:41:55', 'Muhamed Ashik', 'Muhamedashik@gmail.com', 'Really nice mobile. I am also using this mobile. no any erros until now', 'Muhamed Ashik', 'ON', 10),
(20, 'February-06-06 13:45:46', 'Rizmy', 'Rizmy@gmail.com', 'Nice laptop', 'Muhamed Ashik', 'ON', 9),
(21, 'February-06-06 13:50:43', 'Muhamed Ashik', 'MuhamedAshik@gmail.com', 'Testing Comment', 'Muhamed Ashik', 'ON', 16),
(22, 'February-06-06 13:51:33', 'Ashik', 'Ashik@gmail.com', 'Waste laptop', 'Muhamed Ashik', 'OFF', 9),
(24, 'February-06-06 14:45:16', 'Sharaf', 'Sharaf@gmail.com', 'Bought New One', 'Pending', 'OFF', 8),
(26, 'February-15-15 19:21:21', 'Ashik', 'Ashik@gmail.com', 'Nice game', 'Pending', 'OFF', 15);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) NOT NULL,
  `datetime` varchar(50) NOT NULL,
  `title` varchar(300) NOT NULL,
  `category` varchar(50) NOT NULL,
  `author` varchar(30) NOT NULL,
  `image` varchar(50) NOT NULL,
  `postdescription` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `datetime`, `title`, `category`, `author`, `image`, `postdescription`) VALUES
(7, 'February-01-01 12:41:14', 'Apple IPhone 12', 'Technology', 'Mohamed Ashik', 'iPhone 12.png', 'Nice phone to use '),
(8, 'January-27-27 12:52:40', 'Apple IPhone 13', 'Technology', 'Mohamed Ashik', 'iphone 13.jpg', 'This is Apple IPhone 13. Good phone to use'),
(9, 'January-27-27 12:53:16', 'Asus Laptop', 'Technology', 'Mohamed Ashik', 'asus.jpg', 'This is the Asus laptop. not good but fine'),
(10, 'January-27-27 12:53:44', 'Oppo A15', 'Technology', 'Ashik', 'OppoA15.jpg', 'This is one of the best mobile '),
(11, 'January-27-27 16:44:30', 'Oppo Mobile', 'Technology', 'Mohamed Ashik', 'Oppo.jpg', 'THis is also a good phone. friendly to use it'),
(12, 'January-27-27 12:55:30', 'Exercise For  Human', 'Fitness', 'Ashik', 'fitness.jpg', 'Exercise are important for a human beign.'),
(13, 'January-27-27 12:57:32', 'Football', 'Sports', 'Mohamed Ashik', 'Football.jpg', 'Nice sport to play. but risky'),
(14, 'February-09-09 17:01:01', 'Batminton', 'Sports', 'Mohamed Ashik', 'batminton.png', 'Superb game. not any risks'),
(15, 'January-27-27 12:58:14', 'Basketball ', 'Sports', 'Mohamed Ashik', 'backetball.jpg', 'Nice game to play. No risk much'),
(16, 'February-15-15 20:34:21', 'PHP scripting language', 'Technology', 'Ashik', 'PHP.png', 'Fast and powerfull backend language'),
(17, 'February-15-15 17:52:07', 'Arabic Kuthu Song', 'News', 'Ashik', '', 'In 2 hours 10 million views'),
(18, 'February-15-15 17:52:58', 'Beast', 'News', 'Mohamed Ashik', '', 'Upcoming Vijay Flim'),
(19, 'February-15-15 17:58:49', 'Petrol', 'News', 'Muhamed Ashik', '', 'Petrol price is increased');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `Foreign_Relation` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
testing